import { useState, useCallback } from 'react';
import { WORD_LIST } from './words';
import { Copy, RefreshCw, ShieldCheck, Check, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [phrase, setPhrase] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const generatePhrase = useCallback(() => {
    const array = new Uint32Array(12);
    window.crypto.getRandomValues(array);
    const newPhrase = Array.from(array).map((val) => WORD_LIST[val % WORD_LIST.length]);
    setPhrase(newPhrase);
    setCopied(false);
  }, []);

  const copyToClipboard = async () => {
    if (phrase.length === 0) return;
    try {
      await navigator.clipboard.writeText(phrase.join(' '));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy!', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-[#1a1a1a] font-sans selection:bg-emerald-100 selection:text-emerald-900">
      <div className="max-w-3xl mx-auto px-6 py-12 md:py-24">
        {/* Header */}
        <header className="mb-12 text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-medium mb-4">
            <ShieldCheck size={14} />
            <span>Secure Generation</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-semibold tracking-tight mb-4">
            Secret Phrase Generator
          </h1>
          <p className="text-lg text-neutral-500 max-w-xl">
            Generate a secure 12-word recovery phrase using the standard BIP-39 word list. 
            Never share this phrase with anyone.
          </p>
        </header>

        {/* Main Action Area */}
        <main className="space-y-8">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-neutral-200/50">
            {phrase.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
                <AnimatePresence mode="popLayout">
                  {phrase.map((word, index) => (
                    <motion.div
                      key={`${word}-${index}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-neutral-50 border border-neutral-100 group hover:border-emerald-200 transition-colors"
                    >
                      <span className="text-[10px] font-mono text-neutral-400 w-4">
                        {index + 1}
                      </span>
                      <span className="font-medium text-neutral-800">
                        {word}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center border-2 border-dashed border-neutral-100 rounded-2xl mb-8">
                <div className="w-12 h-12 rounded-full bg-neutral-50 flex items-center justify-center mb-4">
                  <RefreshCw className="text-neutral-300" size={24} />
                </div>
                <p className="text-neutral-400 font-medium">
                  Click the button below to generate your phrase
                </p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={generatePhrase}
                className="flex-1 flex items-center justify-center gap-2 bg-[#1a1a1a] text-white px-6 py-4 rounded-2xl font-medium hover:bg-neutral-800 transition-all active:scale-[0.98]"
              >
                <RefreshCw size={18} className={phrase.length > 0 ? "animate-spin-once" : ""} />
                {phrase.length > 0 ? "Regenerate Phrase" : "Generate Phrase"}
              </button>
              
              {phrase.length > 0 && (
                <button
                  onClick={copyToClipboard}
                  className={`flex items-center justify-center gap-2 px-6 py-4 rounded-2xl font-medium transition-all active:scale-[0.98] border ${
                    copied 
                      ? "bg-emerald-50 border-emerald-200 text-emerald-700" 
                      : "bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50"
                  }`}
                >
                  {copied ? <Check size={18} /> : <Copy size={18} />}
                  {copied ? "Copied!" : "Copy Phrase"}
                </button>
              )}
            </div>
          </div>

          {/* Security Notice */}
          <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-6 flex gap-4">
            <div className="shrink-0 text-amber-600">
              <Info size={20} />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-amber-900">Security Best Practices</h3>
              <ul className="text-sm text-amber-800/80 list-disc list-inside space-y-1">
                <li>Write your phrase down on physical paper.</li>
                <li>Store it in a secure, fireproof location.</li>
                <li>Never store your phrase in a digital format (email, cloud, etc.).</li>
                <li>Anyone with these 12 words can access your funds.</li>
              </ul>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="mt-24 pt-8 border-t border-neutral-200 text-center">
          <p className="text-xs text-neutral-400 uppercase tracking-widest font-medium">
            Standard BIP-39 Compliant • Client-Side Only
          </p>
        </footer>
      </div>
    </div>
  );
}
